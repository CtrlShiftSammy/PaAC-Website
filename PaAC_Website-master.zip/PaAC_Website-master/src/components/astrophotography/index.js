import React from "react";
import './astrophotography.css';
import NavBar from "../navbar";

function Astrophotography () {
    return (
        <>
        <section className="astrophotography">
          <NavBar></NavBar>
      <div className="astrophotography">

      </div>
    </section>
        </>
    )
}

export default Astrophotography;