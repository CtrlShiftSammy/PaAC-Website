import React from "react";
import './instruments.css';
import NavBar from "../navbar";

function Instruments () {
    return (
        <>
        <section className="instruments">
          <NavBar></NavBar>
      <div className="instruments">

      </div>
    </section>
        </>
    )
}

export default Instruments;